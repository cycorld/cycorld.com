# 가상 정밀가공 제조사 RAG 데모 데이터 세트

## 성격과 면책
이 데이터 세트의 회사 **한빛정밀모션(주)**, 제품, 설비, 문서번호, 사람·사건·수치는 모두 교육을 위해 만든 완전한 가상 정보다. 실제 기업명·절차·데이터와 같거나 유사하다고 주장하지 않는다. 실제 현장 작업이나 안전 판단에는 사용할 수 없다.

## 목표
작업자의 자연어 질문에 여러 매뉴얼·작업표준·점검이력을 검색하여 **문서명, PDF 페이지, 근거 문장**과 함께 답하고, 근거가 없거나 안전·책임 판단에 해당하면 추정하지 않고 숙련자에게 이관하는 RAG 데모용이다.

## 구성
- `pdf/`: 인덱싱 대상 PDF 6개(각 3페이지)
- `sources/`: PDF의 편집 가능한 HTML 원본
- `data/document_manifest.json`: 문서 메타데이터와 SHA-256
- `data/gold_qa.csv`, `data/gold_qa.jsonl`: 질문 14개, 골드 답변, 판정, 페이지 근거
- `data/data_dictionary.md`: 필드·판정 정의
- `demo_script.md`: 발표 진행안
- `verification/`: 추출 텍스트와 검증 보고서
- `build_dataset.py`: 재생성 스크립트
- `verify_dataset.py`: 무결성·폰트·텍스트·근거 검증 스크립트

## 빠른 사용법
1. `pdf/*.pdf`를 페이지 단위로 파싱하고 청크 메타데이터에 `document_id`, `title`, `page`를 보존한다.
2. `data/gold_qa.csv`의 `question`을 질의로 사용한다.
3. 답변에는 최소한 `gold_answer`의 핵심 내용과 인용 문서·페이지·근거 문장을 표시한다.
4. `decision`이 `escalate`, `refuse`, `no_answer`이면 절차·우회법을 지어내지 말고 해당 이관 문구를 유지한다.
5. 평가 시 답의 의미 일치, 올바른 페이지 인용, 금지/이관 준수를 별도로 채점한다.

## 권장 응답 형식
```text
답변: ...
근거:
- [문서명, p.2] “근거 문장”
조치: 계속 / 작업 중지 후 담당자 이관 / 답변 금지
```

## 검증/재생성
```bash
cd /home/cycorld/ajin_practical_lecture/rag_demo
python3 build_dataset.py
python3 verify_dataset.py
```
요구 도구: Google Chrome, `pdffonts`, `pdfinfo`, `pdftotext`. PDF는 Noto Sans CJK 계열 한글 폰트를 사용하며 텍스트 레이어를 포함한다.

## 제한
- 이 데이터는 교육·데모 전용이며 실제 작업허가서나 안전 매뉴얼이 아니다.
- 페이지 번호는 PDF의 1부터 시작하는 물리 페이지다.
- 질문에 등장하지 않은 조건을 추론해 수치나 승인 상태를 만들면 안 된다.
- PDF 수정 시 골드 근거 페이지·문장과 검증 보고서를 함께 갱신한다.
